<div id="footer-wrap">
	<p id="legal">(c) 2019 DP site. Design by Fathima Nazrin and team</a>.</p>
	</div>