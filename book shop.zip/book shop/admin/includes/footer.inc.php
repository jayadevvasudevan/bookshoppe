<div id="footer-wrap">
	<p id="legal">dp site,developed by Fathima and Co</a>.</p>
	</div>