<?php

	$link=mysqli_connect("localhost","root","")or die("Can't Connect...");
			
			mysqli_select_db($link,"final_shop") or die("Can't Connect to Database...");
		
			$id = $_GET['con_nm'];
			
			$query="delete from contact where con_nm =".$id;
		
			mysqli_query($link,$query) or die("can't Execute...");
			
			
			header("location:contact.php");

?>