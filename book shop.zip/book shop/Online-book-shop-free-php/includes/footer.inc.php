<div id="footer-wrap">
	<p id="legal">(c) 2010 OurSite. Design by <a href="developer.php">Saravaiya Darshana , Halavadiya Shital</a>.</p>
	</div>