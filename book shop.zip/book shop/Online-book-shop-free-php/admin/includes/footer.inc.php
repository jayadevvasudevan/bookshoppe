<div id="footer-wrap">
	<p id="legal">(c) 2010 OurSite. Design by <a href="http://www.freecsstemplates.org/">Saravaiya Darshana , Halavadiya Shital</a>.</p>
	</div>